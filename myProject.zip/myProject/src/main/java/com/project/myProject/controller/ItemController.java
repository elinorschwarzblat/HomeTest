package com.project.myProject.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.project.myProject.model.Item;
import com.project.myProject.repository.ItemRepository;



@RestController
@RequestMapping("api/v1/")
public class ItemController {
	
	@Autowired
	private ItemRepository itemRepository;
	
	@RequestMapping(value="Items",method=RequestMethod.GET)
	public List<Item> list(){
		return itemRepository.findAll();
	}
	
	@RequestMapping(value="Items",method=RequestMethod.POST)
	public Item creat(@RequestBody Item item){
		return itemRepository.saveAndFlush(item);
		//return ItemStub.create(item);
	}
	
	@RequestMapping(value="Items/{id}",method=RequestMethod.GET)
	public Item get(@PathVariable Integer id){
		return itemRepository.getOne(id);
		//return ItemStub.get(id);
	}
	
/*
	@RequestMapping(value="Items/{id}",method=RequestMethod.PUT)
	public Item update(@PathVariable Integer id, @RequestBody Item item){
		Item existingItem= itemRepository.getOne(id);
		BeanUtils.copyProperties(item,existingItem);
		return itemRepository.saveAndFlush(existingItem);
		//return ItemStub.update(id, item);
	 
	}*/
	
	@RequestMapping(value="Items/{id}",method=RequestMethod.DELETE)
	public Item delete(@PathVariable Integer id){
		Item item = itemRepository.getOne(id);
		itemRepository.delete(item);
		return item;
		//return ItemStub.delete(id);
	}
	
	@RequestMapping(value="Items/deposit/{id}/{amount}",method=RequestMethod.PUT)
	public Item deposit(@PathVariable Integer id,@PathVariable Integer amount){
		Item item = itemRepository.getOne(id);
		item.setAmount(item.getAmount()+amount);
		itemRepository.saveAndFlush(item);
		return item;
		
		//return ItemStub.deposit(id, amount);
	}
	
	@RequestMapping(value="Items/withdrawal/{id}/{amount}",method=RequestMethod.PUT)
	public Item withdrawal(@PathVariable Integer id, @PathVariable Integer amount){
		Item item = itemRepository.getOne(id);
		if (item.getAmount()>=amount) {
			item.setAmount(item.getAmount()-amount);
			itemRepository.saveAndFlush(item);
		}
		return item;
		//return ItemStub.withdrawal(id, amount);
	}

	

}
