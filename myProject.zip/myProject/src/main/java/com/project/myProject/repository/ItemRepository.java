package com.project.myProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import com.project.myProject.model.Item;

public interface ItemRepository extends JpaRepository<Item,Integer > {

}
